use std::fs::File;
use std::io::{self, Write, BufWriter};
use printpdf::*;
use uuid::Uuid;

struct Student {
    name: String,
    total_marks: f32,
    num_subjects: u32,
}

impl Student {
    fn average(&self) -> f32 {
        self.total_marks / self.num_subjects as f32
    }

    fn grade(&self) -> char {
        let avg = self.average();
        match avg {
            90.0..=100.0 => 'A',
            75.0..=89.99 => 'B',
            60.0..=74.99 => 'C',
            _ => 'D',
        }
    }
}

fn get_input(prompt: &str) -> String {
    let mut input = String::new();
    print!("{}", prompt);
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut input).unwrap();
    input.trim().to_string()
}

fn generate_pdf(student: &Student) {
    let (doc, page1, layer1) =
        PdfDocument::new("Student Report Card", Mm(210.0), Mm(297.0), "Layer 1");
    let current_layer = doc.get_page(page1).get_layer(layer1);

    let font = doc.add_builtin_font(BuiltinFont::HelveticaBold).unwrap();

    let report_text = format!(
        "📝 Report Card\n\n\
Name: {}\n\n\
Total Marks: {}\n\n\
Subjects: {}\n\n\
Average: {:.2}\n\n\
Grade: {}",
        student.name,
        student.total_marks,
        student.num_subjects,
        student.average(),
        student.grade()
    );

    current_layer.use_text(report_text, 14.0, Mm(20.0), Mm(270.0), &font);

    let file_name = format!("report_{}.pdf", Uuid::new_v4());
    let file = File::create(&file_name).unwrap();
    let mut buffer = BufWriter::new(file);
    doc.save(&mut buffer).unwrap();

    println!("✅ Report card generated successfully: {}", file_name);
}

fn main() {
    println!("📘 Welcome to the Rust Student Report Card Generator!");

    let name = get_input("Enter student name: ");
    let total_marks: f32 = get_input("Enter total marks: ").parse().unwrap();
    let num_subjects: u32 = get_input("Enter number of subjects: ").parse().unwrap();

    let student = Student {
        name,
        total_marks,
        num_subjects,
    };

    generate_pdf(&student);
}
